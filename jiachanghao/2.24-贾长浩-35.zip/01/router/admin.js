// 二级路由分发
const express = require('express');
const router = express.Router();

// 连接数据库
require('../db/db');
const User = require('../db/ruledb');

// User.create({
//     uname: 'jch',
//     parssword: '123'
// })

// 登录
router.get('/login', require('./admin-all/login.js'));
// 注册
router.get('/register', require('./admin-all/register.js'));
// 后台管理页面
router.get('/index', require('./admin-all/index.js'));
// 添加页面
router.get('/add', require('./admin-all/add.js'));
// 修改页面
router.get('/dit', require('./admin-all/dit.js'));

// 暴露
module.exports = router;