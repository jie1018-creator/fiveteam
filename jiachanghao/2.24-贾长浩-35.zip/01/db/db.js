const mongoose = require('mongoose');

const DB = new mongoose.connect('mongodb://localhost/uadmin', { useNewUrlParser: true, useUnifiedTopology: true });

DB.then(() => {
    console.log('数据库链接成功');
}, () => {
    console.log('数据库链接失败');
});