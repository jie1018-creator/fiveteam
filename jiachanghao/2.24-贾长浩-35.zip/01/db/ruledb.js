const mongoose = require('mongoose');
// 用户名规则
const scheam = new mongoose.Schema({
    uname: {
        type: String,
    },
    parssword: {
        type: String,
    },
    data: {
        type: Date,
        default: Date.now,
    }
});

const User = mongoose.model('users', scheam);

// 暴露
module.exports = User;