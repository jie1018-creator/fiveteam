const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const app = express();
const cors = require('cors');

// 跨域
app.set(cors());

// 设置ejs引擎
app.set('view engine', 'ejs');

// 静态托管
app.use(express.static('public'));
app.use(bodyParser.urlencoded({
    extended: false
}));
app.use(bodyParser.json());

// 一级路由
app.use('/admin', require('./router/admin'));

// 端口监听
app.listen(3000, () => {
    console.log('3000端口开启');
});