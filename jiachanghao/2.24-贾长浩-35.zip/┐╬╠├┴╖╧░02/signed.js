const express = require('express');
// 引入cookie模块
const cookieParser = require('cookie-parser');
const app = express();

// 设置拦截
app.use(cookieParser('8'));

// 设置cookie
app.get('/set', (req, res) => {
    res.cookie('uname', '1234', {
        // cookie失效时间
        maxAge: 60 * 1000,
        // 设置signed
        signed: true
    })
    res.send('ok')
})

// 获取cookie
app.get('/get', (req, res) => {
    // 获取cookie req.signedCookies
    res.send(req.signedCookies);
});

// 监听端口
app.listen(3000, () => {
    console.log('3000');
})