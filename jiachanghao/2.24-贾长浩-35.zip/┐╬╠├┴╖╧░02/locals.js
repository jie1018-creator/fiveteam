const express = require('express');
const app = express();
const ejs = require('ejs');

app.set('view engine', 'ejs');

app.locals.user = {
    uname: '王美玲'
};

app.get('/a', (req, res) => {
    res.render('1');
})

app.get('/b', (req, res) => {
    res.render('2');
});

app.listen(3000, () => {
    console.log('3000');
})