const express = require('express');
const session = require('express-session');
const app = express();

app.use(session({
    // key
    name: 'jch',
    // 值
    secret: '8888',
    // 强制保存session 默认true不保存
    resave: true,
    // 强制保存未初始化的session
    saveUninitialized: true,
    cookie: {
        // ssl协议
        // secure:true,
        // 失效时间
        maxAge: 15 * 1000,
    },
    // 强制重置cookie过期时间
    rolling: true
}));

// 设置session
app.get('/set', (req, res) => {
    // 设置session属性
    req.session.uname = '6666';
    res.send('成功');
});

// 获取session
app.get('/get', (req, res) => {
    if (req.session.uname) {
        res.send(req.session.uname);
    } else {
        res.send('请重新登录');
    };
});

app.listen(3000, () => {
    console.log('3000开启');
});