const express = require('express');
const cookieparser = require('cookie-parser');
const app = express();

// 设置拦截
app.use(cookieparser());

// 设置cookie
app.get('/set', (req, res) => {
    res.cookie('uname', '123', {
        // 设置cookie失效时间
        maxAge: 24 * 60 * 60 * 1000,
    });
    res.send('设置成功');
})

// 获取cookie
app.get('/get', (req, res) => {
    res.send(req.cookies);
})

// 监听端口
app.listen(3000, () => {
    console.log('3000端口已开启');
});