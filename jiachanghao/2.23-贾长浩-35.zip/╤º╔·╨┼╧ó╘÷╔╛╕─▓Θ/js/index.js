// 请求地址
var uRl = 'http://localhost:3008';

// 显示数据
$.get(uRl + '/api/student/getStudent', function(data) {
    strjoin(data, '#tbody_stu');
}, 'json');

// 搜索数据
$('#search_btn').on('click', function() {
    $.get(uRl + '/api/student/getStudent', {
        name: $('#searchvalue').val()
    }, function(data) {
        strjoin(data, '#tbody_stu');
    }, 'json');
});

// 添加数据
$('.header>a').on('click', function() {
    // 添加
    $('.masking').fadeIn();
    emptyall();
});
$('.cancel').on('click', function() {
    // 取消
    $('.masking').fadeOut();
    emptyall();
});

// 获取表单
var obj = new Object();

function forminpt() {
    // 获取文本信息
    $('.information').each(function(index, value) {
        obj[value.name] = $(value).val();
    });
    // 获取单选框性别
    $('.genderall').each(function(index, value) {
        if ($(value).prop('checked')) {
            obj[value.name] = $(value).val();
        };
    });
    // 获取多选框爱好
    obj.hobby = $('.hobby').map(function(index, value) {
        if ($(value).prop('checked')) {
            return $(value).val();
        };
    }).toArray().join();
};

// 添加数据
$('.addition').off().on('click', function() {
    forminpt();
    console.log(obj);
    $.post(uRl + '/api/student/addStudent', obj, function(data) {
        strjoin(data, '#tbody_stu');
    }, 'json');
    $('.masking').fadeOut();
});

// 获取元素信息
function eleall() {
    // 删除信息
    $('.delete_btn').on('click', function() {
        $.get(uRl + '/api/student/removeStudent', {
            id: $(this).parents('tr').find('td:first').text()
        }, (data) => {
            $(this).parents('tr')[0].remove();
            // strjoin(data, '#tbody_stu');
            console.log(data);
        }, 'json');
    });
    // 修改信息
    $('.update_btn').on('click', function() {
        $('.masking').fadeIn();
        $('.addition').css('display', 'none');
        $('.amend').css('display', 'block');
        $.getJSON(uRl + '/api/student/getStudent', {
            id: $(this).parents('tr').find('td:first').text()
        }, function(data) {
            console.log(data);
            editInformation(data[0]);
        });
    });
};

function editInformation(data) {
    $('.displayyes').fadeIn();
    $('.idName').val(data.id);
    // 放文本信息
    $('.information').each(function(index, value) {
        $(value).val(data[value.name]);
    });
    // 放性别
    $('.genderall').each(function(index, value) {
        if ($(value).prop('checked')) {
            if ($(value).val() != data.gender) {
                $(value).prop('checked', false);
            };
        } else {
            if ($(value).val() == data.gender) {
                $(value).prop('checked', true);
            };
        };
    });
    // 放爱好
    $('.hobby').each(function(index, value) {
        if (data.hobby.includes($(value).val())) {
            $(value).prop('checked', true);
        };
    });
    // 修改
    $('.amend').off().on('click', function() {
        forminpt();
        obj.id = data.id;
        $.post(uRl + '/api/student/updateStudent', obj, function(data) {
            strjoin(data, '#tbody_stu');
        }, 'json');
        $('.masking').fadeOut();
        emptyall();
    });
};

// 拼接串
function strjoin(data, target) {
    var str;
    $(data).each(function(index, value) {
        str += `<tr>
                <td>${value.id}</td>
                <td>${value.clazz}</td>
                <td>${value.name}</td>
                <td>${value.gender}</td>
                <td>${value.age}</td>
                <td>${value.tel}</td>
                <td>${value.hobby}</td>
                <td>${value.address}</td>
                <td>${value.remark}</td>
                <td>${value.date}</td>
                <td><a href="javascript:;" class="update_btn">修改</a><a href="javascript:;" class="delete_btn">删除</a></td></tr>`;
    });
    $(target).html(str);
    eleall();
};

// 取消和确定初始化
function emptyall() {
    $('.information').val('');
    $('.genderall:first').prop('checked', true);
    $('.hobby').prop('checked', false);
    $('.displayyes').fadeOut();
    $('.addition').css('display', 'block');
    $('.amend').css('display', 'none');
};