const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');

// 静态托管
// app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// 跨域
app.use(cors());

// 一级路由
app.use('/api/student/', require('./routes/app.js'));

// 监听端口
app.listen(3008, () => {
    console.log('端口3008开启');
});