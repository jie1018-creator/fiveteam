// 引入模块
const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const mongoose = require('mongoose');
const app = express();

// 设置模板引擎
app.set('view engine', 'ejs');
// 拦截窗体格式
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// 链接数据库
const DB = new mongoose.connect('mongodb://localhost/jch', { useNewUrlParser: true, useUnifiedTopology: true });
// 数据库链接状态
DB.then(() => {
    console.log('数据库链接成功');
}, () => {
    console.log('数据库链接失败');
});

// 入库规则
const schema = new mongoose.Schema({
    uname: String,
    age: Number,
    sex: String
});
// 创建表名
const User = mongoose.model('users', schema);
// 查询数据
app.get('/', (req, res) => {
    User.find().then((data) => {
        res.render('index', {
            obj: data,
            title: '添加信息'
        });
    });
});

// 搜索数据
app.get('/get', (req, res) => {
    console.log(req.query);
    User.find(req.query).then((data) => {
        res.send(200, data);
    });
});

app.get('/add', (req, res) => {
    res.render('add', { title: '添加信息' });
});

// 添加数据到数据库
app.post('/adds', (req, res) => {
    const user = User(req.body);
    user.save();
    res.send('添加成功<a href="/">查看数据</a>');
});

// 删除数据操作
app.post('/removes', (req, res) => {
    User.remove(req.body, (err) => {
        if (err) {
            console.log('删除失败' + err);
            res.send(500, '删除失败');
        } else {
            console.log('删除成功');
            res.send(200, '删除成功');
        }
    })
});


app.listen(3000, () => {
    console.log('端口开启3000');
});