// 引入模块
const mongoose = require('mongoose');
// 链接数据库
const DB = mongoose.connect('mongodb://localhost/jch', { useNewUrlParser: true, useUnifiedTopology: true });
// 链接数据库状态
DB.then(() => {
    console.log('数据库链接成功');
}, () => {
    console.log('数据库连接失败');
});

// 入库规则
const Schema = new mongoose.Schema({
    uname: String,
    sex: String,
    age: Number,
});

// 创建数据库表名
const User = mongoose.model('users', Schema);

// 创建数据
const user = new User({
    uname: '贾长浩',
    age: 22,
    sex: '男'
});

// 保存数据到集合中
// user.save();

// 查询数据
User.find().then((data) => {
    console.log(data);
});

// 精确查询
// User.find({
//     age: { $gt: 30 }
// }).then((data) => {
//     console.log(data);
// });