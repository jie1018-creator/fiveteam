let url = new URL('http://www.hg-zn.com:3000/login?uname=zhangmeili&password=666#888888');
let urls = url.searchParams;
// console.log(urls);
//得到的格式为{'uname'=>'zhangmeili','password'=>'666'}
//因为里面含有iterator接口,所以可是使用for...of和forEach遍历
// for (let [key, value] of urls) {
//     console.log(key);
//     console.log(value);
// };
// urls.forEach((value, key) => {
//     console.log(value);
//     console.log(key);
// });
//返回完整的url
// console.log(url.toString(urls));
// console.log(url.toJSON(urls));

//url.searchParams的一些方法
//添加键值对
// urls.append('gender', '女');
//删除
// urls.delete('age');
//含有相同键名的键值对
urls.append('grade', 1);
urls.append('grade', 2);
urls.append('grade', 3);
// urls.entries();对象里面是数组,几组键值对就有几个数组,数组里面含有两个值,是由键和值组成的
// console.log(urls.entries());
console.log(url.port); //端口号
console.log(url.href); //完整的url
console.log(url.protocol); //协议http:
console.log(url.origin); //域http://www.hg-zn.com:3000
console.log(url.search);
console.log(url.pathname);
console.log(url.hash); //#后边的,包含#号