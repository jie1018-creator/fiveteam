// 引入查询字符串的模块
let queryStr = require('querystring');
let searchstr = 'uname=zhangmeili&password=666';
//将窗体格式转换成对象,不需要进行分割就可以直接转换成对象
//parse和decode都是将串转化成对象
console.log(queryStr.parse(searchstr));
console.log(queryStr.decode(searchstr));
//将对象转化成窗体格式
//encode,stringify结果一样
//将对象转换成串
console.log(queryStr.encode({ uname: 'zhangmeili', password: '666' }));
console.log(queryStr.stringify({ uname: 'zhangmeili', password: '666' }));
console.log(queryStr.stringify({ uname: 'zhangmeili', password: '666' }, '*', '-'));
//*符号就相当于&符号,-相当于冒号,会进行相应的替换
console.log(queryStr.escape('学习使人进步')); //编码
//解码
console.log(queryStr.unescape('%E5%AD%A6%E4%B9%A0%E4%BD%BF%E4%BA%BA%E8%BF%9B%E6%AD%A5'));