let path = require('path');
//path最后一部分文件名
console.log(path.basename('http://www.hg-zn.com:3000/index.html'));
console.log(path.basename('http://www.hg-zn.com:3000/login?uname=zhangmeili&password=666'));
//目录
console.log(path.dirname('http://www.hg-zn.com:3000/index.html'));
//扩展名
console.log(path.extname('http://www.hg-zn.com:3000/index.html'));
console.log(path.extname('http://www.hg-zn.com:3000/login?uname=zhangmeili&password=666'));
//对象
console.log(path.parse('http://www.hg-zn.com:3000/index.html'));
//拼接
console.log(path.join('file', 'js', '01.js'));