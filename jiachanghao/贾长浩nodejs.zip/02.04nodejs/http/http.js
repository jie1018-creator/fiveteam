//创建一个服务器
// let server = http.createServer((req, res) => {
//     res.writeHead(200, {
//         'Content-Type': 'text/html;charset=utf-8'
//     });
//     res.write('创建简单的服务器');
//     res.end();
// });
//响应
// server.listen(3000, () => {
//     console.log('server is running');
// });

//switch语句
//通过对req.url的判断来进行加载不同的界面
// let server = http.createServer((req, res) => {
//     res.writeHead(200, 'success', {
//         'Content-Type': 'text/html;charset=utf-8'
//     });
//     switch (req.url) {
//         case '/':
//             res.write('是首页');
//             break;
//         case '/index.html':
//             res.write('是首页');
//             break;
//         case '/news.html':
//             res.write('是新闻页面');
//             break;
//         case '/aboutus.html':
//             res.write('是关于我们页面');
//             break;
//         default:
//             res.write('404 Not Found')
//     };
//     res.end('结束')
// });


//读取页面的内容
let http = require('http');
let fs = require('fs');
//读取文件

// let server = http.createServer((req, res) => {
//     res.writeHead(200, 'success', {
//         'Content-Type': 'text/html;charset=utf-8'
//     });
//     if (req.url != '/favicon.ico') {
//路径
// let reqpath = './file' + req.url;
// fs.readFile(reqpath, (err, data) => {
//     if (err) {
//         console.log(err);
//     } else {
//         res.write(data);
//     }
//位置写对,读取文本内容
//             res.end('end');
//         });
//     };
// });


//将url的内容分解存储到对象当中
let urlstr = 'http://localhost:3000/login?uname=zhangmeili&password=666';
let server = http.createServer((req, res) => {
    res.writeHead(200, {
        'Content-Type': 'text/html;charset=utf-8'
    });
    let reurl = req.url;
    if (reurl != '/favicon.ico') {
        let obj = {};
        if (reurl.includes('?')) {
            // ['uname=zhangmeili', 'password=666']
            var arr = reurl.split('?')[1].split('&');
            arr.forEach(value => {
                var temp = value.split('=');
                obj[temp[0]] = temp[1];
            })
        };
        console.log(obj);
        res.end('提交成功')
    } else {
        res.end('参数错误')
    }
});
server.listen(3000, () => {
    console.log('server is running');
});