const express = require('express');
const app = express();
const bodyParser = require('body-parser');
app.use(expres.static(__dirname)); //设置静态资源
app.use(bodyParser.urlencoded({ extended: false })); //窗体格式
app.use(bodyParser.json()); //json格式
app.post('/login', (req, res) => {
    res.send(req.body);
});
app.listen(3000, () => {
    console.log('已经开启');
});