const express = require('express');
const app = express();
app.get('/user', (req, res) => {
    res.send(req.query);
});
//http://127.0.0.1:3000/user?name=wangshuai&age=25&gender=男
//通过req.query得到get的参数


//得到路由的参数
app.get('/admin/:id/:name/:age', (req, res) => {
    res.send(200, req.params);
});
app.listen(3000, () => {
    console.log('已开启');
});