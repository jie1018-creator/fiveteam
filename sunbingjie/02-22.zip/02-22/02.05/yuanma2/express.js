const express = require('express');
const app = express();
// app.get("/", (req, res) => {
//     res.send("hello express")
// });


// 中间件使用
// app.get('/', (req, res, next) => {
//     req.name = '王帅';
//     next();
// });
// app.get("/", (req, res) => {
//     res.send(req.name)
// });



//use中间件使用
//use匹配所有的请求方式
// app.use((req, res, next) => {
//     if (req.url == '/login') {
//         next();
//     } else {
//         res.send(404, '未找到资源');
//     };
// });
// app.use('/login', (req, res) => {
//     res.send('找到页面')
// });


//get参数的获取,使用req.query
// app.get('/login', (req, res) => {
//     if (req.query.name == 'wangshuaishuai' && req.query.password == '88888888') {
//         res.send('登录成功');
//     } else {
//         res.send('登录失败');
//     };
// });
//http://localhost:3000/login?name=wangshuaishuai&password=88888888;

//路由
// app.get('/find/:name', (req, res) => {
//     console.log(req.params);
//     res.status(200).send(req.params);
// });
//路由形式
// app.get('/user/id/:uid/name/:name', (req, res) => {
//     console.log(req.params);
//     res.status(200).send(req.params);
// });
app.get('/user/:uid/:name', (req, res) => {
    console.log(req.params);
    res.status(200).send(req.params);
});

//http://localhost:3000/user/4565456/张美丽


app.listen(3000, () => {
    console.log('端口号3000');
});