const express = require('express'); //引入express
const app = express(); //实例化
// app.get('/login', (req, res) => {
//     res.send('express初学');
// });

//使用中间件

// app.get('/admin', (req, res, next) => {
//     req.gender = '女';
//     next();
// });
// app.get('/admin', (req, res) => {
//     res.send(req.gender);
// });


// 使用use中间件
app.use((req, res, next) => {
    if (req.url == '/user') {
        next();
    } else {
        res.send(404, 'NOT FOUND')
    };
});
app.use('/user', (req, res) => {
    res.send(200, '成功找到');
});
app.listen(3000, () => {
    console.log('已经启动');
}); //监听