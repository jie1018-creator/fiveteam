//post请求
const express = require('express');
const app = express();
//引入body-parser
const bodyParser = require('body-parser');
//设置静态资源
app.use(express.static(__dirname));
//配置post请求的参数
app.use(bodyParser.urlencoded({ extended: false })); //窗体格式
app.use(bodyParser.json()); //json格式
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Content-Type', 'application/json');
    next();
});
//设置post请求
app.post('/login', (req, res) => {
    res.send(req.body);
});
//监听
app.listen(3000, () => {
    console.log('已经开启');
});