// 引入模块
const express = require('express');
const router = express.Router();
const fs = require('fs');

router.get('/getstudents', (req, res, next) => {
    res.send(200, '成功');
    console.log('成功');
});