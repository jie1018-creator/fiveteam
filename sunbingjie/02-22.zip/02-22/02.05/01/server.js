// 引入模块
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const fs = require('fs');
app.use(express.static(__dirname));
// 请求json格式
app.use(bodyParser.json());
//请求窗体格式
app.use(bodyParser.urlencoded({ extended: false }));
// 跨域请求
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.set('Content-Type', 'application/json');
    next();
});
// 加载路由
// app.use('/api', require('./public/students'));

app.use((req, res, next) => {
    console.log(req._parsedUrl.pathname);
    if (req._parsedUrl.pathname == '/get' || req._parsedUrl.pathname == '/add') {
        next();
    } else {
        res.send('not found');
        console.log('错误');
    };
});

// 读取文件
app.get('/get', (req, res, next) => {
    console.log(__dirname + '/data/obj.json');
    fs.readFile(__dirname + '/data/obj.json', 'utf8', (err, data) => {
        if (err) {
            console.log('读取错误');
        };
        // console.log(data);
        res.send(200, JSON.parse(data));
    });
});
app.post('/add', (req, res) => {
    fs.readFile(__dirname + '/data/obj.json', 'utf8', (err, data) => {
        if (err) {
            console.log('读取错误');
        };
        // 将时间戳作为id
        req.body.id = Date.now().toString();
        data = JSON.parse(data);
        data.push(req.body);
        console.log(data);
        // 将数据写入到文件
        fs.writeFile(__dirname + '/data/obj.json', JSON.stringify(data), (err) => {
            if (err) {
                console.log('写入失败');
            }
            res.send(200, req.body);
        })
    });
});
// 监听端口
app.listen(3000, () => {
    console.log('后台端口开启3000');
});