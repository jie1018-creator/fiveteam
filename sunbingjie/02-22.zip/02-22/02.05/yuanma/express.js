const express = require('express');
const app = express();
app.get('/', (req, res) => {
    res.send('使用express');
});

//中间件
app.get('/login', (req, res, next) => {
    req.gender = '男';
    next();
});
app.get('/login', (req, res) => {
    // 设置响应的状态码
    // res.status();
    //res.send()也可以写状态码
    res.send(200, req.gender);
});

app.listen(3000, () => {
    console.log('已开启');
});