//使用use中间件
const express = require('express');
const app = express();
app.use((req, res, next) => {
    if (req.url == '/admin') {
        next();
    } else {
        res.send(404, 'Not Found');
    };
});
app.use('/admin', (req, res) => {
    res.send('找到请求的界面');
});
app.listen(3000, () => {
    console.log('已开启');
});