//得到get请求的参数
// req.query:{"name":"张美丽","age":"22","gender":"女"}
const express = require('express');
const app = express();
app.get('/login', (req, res) => {
    res.send(req.query);
});

//路由参数
// {"id":"1231231","uname":"张美丽"}
app.get('/admin/:id/:uname', (req, res) => {
    console.log(req.params.id);
    res.send(200, req.params);
});
app.listen(3000, () => {
    console.log('已开启');
});
//http://localhost:3000/login?name=张美丽&age=22&gender=女