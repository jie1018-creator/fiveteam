const express = require('express');
const app = express();
//引入bodyParser:获取post的请求参数
const bodyParser = require('body-parser');
// 设置静态资源,能够打开文件夹下的所有文件
app.use(express.static(__dirname));
//配置post的请求参数
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// 跨域请求
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Content-Type', 'application/json');
    next();
});
app.post('/addstudent', (req, res) => {
    res.send(200, req.body);
    console.log(req.body);
});
app.listen(3000, () => {
    console.log('已开启');
});