const express = require('express');
const app = express();
const bodyParse = require('body-parser');
app.use(express.static(__dirname)); //设置静态资源
app.post('/admin', (req, res) => {
    res.send(req.body);
});