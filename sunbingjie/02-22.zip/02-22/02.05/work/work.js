let fs = require('fs');
//同步操作没有回调函数
let rel1 = fs.readdirSync('./test');
for (var i = 0; i < rel1.length; i++) {
    fs.unlinkSync('./test/' + rel1[i]);
};
fs.rmdirSync('./test');