const express = require('express');
const app = express();
//使用cookie需要引入cookie-parser
const cookie = require('cookie-parser');
//使用use
//设置签名
app.use(cookie('222'));
//设置cookie
app.get('/setCookie', (req, res) => {
    // 使用res.cookie(key,value,{过期时间,使用签名})
    res.cookie('taste', 'sweet', {
        //时间是毫秒
        maxAge: 24 * 60 * 60 * 1000,
        // 允许使用签名
        signed: true
    });
    //提示信息,发送到页面
    res.send('设置成功')
});
//得到cookie,使用req.cookies
app.get('/getCookie', (req, res) => {
    res.send(req.cookies)
});
app.listen(3000, () => {
    console.log('3000');
});