const express = require('express');
const app = express();
const ejs = require('ejs');
//配置ejs模块
app.set('view engine', 'ejs');
//公共数据app.locals
app.locals.user = {
    uname: '王帅帅'
};
app.get('/admin', (req, res) => {
    res.render('admin');
});
app.get('/user', (req, res) => {
    res.render('user')
});
app.listen(3000, () => {
    console.log('3000端口开启');
});