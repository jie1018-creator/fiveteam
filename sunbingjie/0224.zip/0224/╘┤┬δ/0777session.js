//session使用
const express = require('express');
const app = express();
//引入
const session = require('express-session');
app.use(session({
    secret: '777',
    name: '77',
    //强制保存未初始化session
    saveUninitialized: false,
    //设置过期时间
    cookie: {
        maxAge: 20 * 1000
    },
    rolling: true //强制重置过期时间
}));
app.get('/login', (req, res) => {
    req.session.grader = 'four';
    res.send('注册成功')
});
app.get('/user', (req, res) => {
    if (req.session.grader) {
        res.send('登录成功')
    } else {
        res.send('登录失败,请重新登录')
    }
});
app.listen(3000, () => {
    console.log('3000');
});