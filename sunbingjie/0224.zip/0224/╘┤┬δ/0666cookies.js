const express = require('express');
const app = express();
//引入cookie-parser
const cookie = require('cookie-parser');
//设置cookie
app.use(cookie('nnn')); //设置签名
app.get('/setcookie', (req, res) => {
    res.cookie('school', '希望小学', {
        maxAge: 60 * 60 * 1000, //过期时间
        signed: true //允许使用签名
    });
    res.send('提示信息,设置成功')
});
//获取cookie
app.get('/getcookie', (req, res) => {
    res.send(req.signedCookies); //使用签名时,需要用req.signedCookies获取所有数据,
    //设置签名后用req.cookies是获取不到数据的
});
app.listen(3000, () => {
    console.log('3000');
});