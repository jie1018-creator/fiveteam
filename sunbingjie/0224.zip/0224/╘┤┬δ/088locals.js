// 设置公共数据
const express = require('express');
const app = express();
const ejs = require('ejs');
app.set('view engine', 'ejs');
app.locals.user = {
    uname: 'zhangsan'
};
app.get('/admin', (req, res) => {
    res.render('admin');
});
app.get('/user', (req, res) => {
    res.render('user')
});
app.listen(3000, () => {
    console.log('3000端口开启');
});