const express = require('express');
const app = express();
const cookieParser = require('cookie-parser');
//设置签名的字符串,加密
app.use(cookieParser('6666'));
app.get('/setCookie', (req, res) => {
    res.cookie('gender', 'man', {
        maxAge: 24 * 60 * 60 * 1000,
        // 设置允许使用signed
        signed: true
    });
    res.send('设置成功');
});
app.get('/getCookie', (req, res) => {
    console.log(req.cookies); //使用签名字符串后得不到数据
    console.log(req.signedCookies); //后台得到 { name: 'liming', gender: 'man' }
    res.send(req.cookies)
});
app.listen(3000, () => {
    console.log('3000开启');
});