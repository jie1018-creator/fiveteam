//session使用
const express = require('express');
const app = express();
//引入session-cookie
const session = require('express-session');
app.use(session({
    secret: 'ddd',
    name: 'session',
    // 强制保存未初始化session
    saveUninitalized: true,
    //过期时间
    cookie: {
        maxAge: 30 * 1000
    },
    //强制cookie过期时间
    rolling: true
}));
//先设置信息,再进行判断是否含有数据,之后进行登录
app.get('/login', (req, res) => {
    req.session.address = '商丘';
    res.send('注册成功');
});
app.get('/home', (req, res) => {
    if (req.session.address) {
        res.send('登录成功')
    } else {
        res.send('请重新登录')
    }
});
app.listen(3000, () => {
    console.log('3000');
});