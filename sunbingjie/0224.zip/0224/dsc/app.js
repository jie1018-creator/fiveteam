const express = require('express');
const app = express();
const ejs = express('ejs');
const bodyParser = require('body-parser');
//设置静态资源
app.use(express.static('public'));
app.set('view engine', 'ejs');
//窗体格式和json格式
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
//路由分发,一级二级
app.use('/admin', require('./routes/admin.js'));
app.listen(3000, () => {
    console.log('端口3000已经开启');
});