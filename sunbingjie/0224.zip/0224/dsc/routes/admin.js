// 二级路由
const express = require('express');
const router = express.Router();
// 登录页面
router.use('/login', require('./admin-router/login.js'));
//产品添加页面
router.use('/addproduct', require('./admin-router/addproduct.js'));
//修改
router.use('/editproduct', require('./admin-router/editproduct.js'));
//产品列表
router.use('/productlist', require('./admin-router/productlist.js'));
module.exports = router;