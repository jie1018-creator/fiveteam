//获取tbody
var tbodyStu = document.querySelector('#tbody_stu');
//获取搜索按钮,搜索框里面的值
var searchBtn = document.querySelector('#search_btn');
var searchValue = document.querySelector('#searchvalue');
//添加按钮
var addBtn = document.getElementById('add_btn');
//封装函数，得到数据
getData(baseUrl + '/api/student/getStudent', '', pageShow);

function pageShow(objValue) {
    var arr = JSON.parse(objValue.response);
    var content = '';
    for (var i = 0; i < arr.length; i++) {
        content += `<tr>
        <td>${arr[i].id}</td>
        <td>${arr[i].clazz}</td>
        <td>${arr[i].name}</td>
        <td>${arr[i].gender}</td>
        <td>${arr[i].age}</td>
        <td>${arr[i].tel}</td>
        <td>${arr[i].hobby}</td>
        <td>${arr[i].address}</td>
        <td>${arr[i].remark}</td>
        <td>${arr[i].date}</td>
        <td><a href="update.html?id=${arr[i].id}" class="change_btn" id="${arr[i].id}">修改</a>&emsp;<a href="#" class="delete_btn" >删除</a></td></tr>`;
    };

    if (!content) {
        content = '<tr><td>没有查询到数据</td></tr>'
    };
    tbodyStu.innerHTML = content;
    deleteValue();
};

//搜索数据
searchBtn.onclick = function() {
    var sea = searchValue.value.trim();
    getData(baseUrl + '/api/student/searchStudent', { name: sea }, pageShow);
};
//删除数据
function deleteValue() {
    var delBtn = document.getElementsByClassName('delete_btn');
    for (var i = 0; i < delBtn.length; i++) {
        delBtn[i].onclick = function(e) {
            var getId = this.parentNode.parentNode.firstElementChild.innerText;
            var flag = confirm('你确定要删除吗？');
            if (flag) {
                this.parentNode.parentNode.remove();
                getData(baseUrl + '/api/student/removeStudent', { id: getId }, pageShow);
            };
        };
    };
    //修改
    var changeBtn = document.querySelectorAll('.change_btn');
    for (var j = 0; j < changeBtn.length; j++) {
        changeBtn[j].onclick = function() {
            //得到id
            localStorage.setItem('updateId', this.id);
        };
    };
};
















//普通写法
//得到所有的数据
// var xhr = new XMLHttpRequest();
// xhr.open('GET', 'http://localhost:3008/api/student/getStudent');
// xhr.send(null);
// xhr.onreadystatechange = function() {
//     if (xhr.readyState == 4 && xhr.status == 200) {
//         var arr = JSON.parse(xhr.response);
//         var content = '';
//         for (var i = 0; i < arr.length; i++) {
//             content += `<tr>
//         <td>${arr[i].id}</td>
//         <td>${arr[i].clazz}</td>
//         <td>${arr[i].name}</td>
//         <td>${arr[i].gender}</td>
//         <td>${arr[i].age}</td>
//         <td>${arr[i].tel}</td>
//         <td>${arr[i].hobby}</td>
//         <td>${arr[i].address}</td>
//         <td>${arr[i].remark}</td>
//         <td>${arr[i].date}</td>
//         <td><a href="#" class="change">修改</a><a href="#" class="delete_btn">删除</a></td></tr>`
//         };
//         if (!content) {
//             content = '<tr><td colspan="11">没有查询到数据</td></tr>'
//         };
//         tbodyStu.innerHTML = content;
//     };
// };
//查询数据
// searchBtn.onclick = function() {
//     xhr.open('GET', 'http://localhost:3008/api/student/getStudent?name=' + searchValue.value);
//     xhr.send(null);
//     xhr.onreadystatechange = function() {
//         if (xhr.readyState == 4 && xhr.status == 200) {
//             var arr = JSON.parse(xhr.response);
//             var content = '';
//             for (var i = 0; i < arr.length; i++) {
//                 content += `<tr>
//             <td>${arr[i].id}</td>
//             <td>${arr[i].clazz}</td>
//             <td>${arr[i].name}</td>
//             <td>${arr[i].gender}</td>
//             <td>${arr[i].age}</td>
//             <td>${arr[i].tel}</td>
//             <td>${arr[i].hobby}</td>
//             <td>${arr[i].address}</td>
//             <td>${arr[i].remark}</td>
//             <td>${arr[i].date}</td>
//             <td><a href="#" class="change">修改</a><a href="#" class="delete_btn">删除</a></td></tr>`
//             };
//             if (!content) {
//                 content = '<tr><td colspan="11">没有查询到数据</td></tr>'
//             };
//             tbodyStu.innerHTML = content;
//         };
//     };
// };