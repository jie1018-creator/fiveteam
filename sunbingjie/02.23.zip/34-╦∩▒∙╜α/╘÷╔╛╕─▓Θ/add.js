//获取所有输入的值
var info = document.querySelectorAll('.info');
//获取性别
var gender = document.querySelectorAll('.gender');
//获取爱好
var hobbies = document.querySelectorAll('.hobbies');
//所有的数据,创建空对象
var allStuData = {};
addForm.onsubmit = function(e) {
    for (var i = 0; i < info.length; i++) {
        allStuData[info[i].name] = info[i].value;
    };
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allStuData.gender = gender[j].value;
            break;
        };
    };
    var arrStu = [];
    for (var k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            arrStu.push(hobbies[k].value);
        };
    };
    allStuData.hobby = arrStu.join();
    postData(baseUrl + '/api/student/addStudent', allStuData, function() {
        location.href = location.origin + '/index.html';
    });
    console.log(allStuData);
    e.preventDefault();

};