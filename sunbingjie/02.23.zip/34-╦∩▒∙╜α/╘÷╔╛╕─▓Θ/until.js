var baseUrl = 'http://localhost:3008';

function getData(url, data, fun) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url + '?' + objFormat(data));
    xhr.send(null);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        };
    };
};

function objFormat(objs) {
    if (!objs) {
        return '';
    };
    var arrTem = [];
    for (var key in objs) {
        arrTem.push(key + '=' + objs[key]).toString();
    };
    return arrTem.join('&');
};
//添加数据,封装函数
function postData(url, data, fun) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.setRequestHeader('Content-Type', 'application/json');
    var dataJson = JSON.stringify(data);
    // 发送
    xhr.send(dataJson);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            fun(xhr);
        };
    };
}