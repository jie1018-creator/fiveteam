var updateForm = document.querySelector('#updateForm');
var updateInfo = document.querySelectorAll('.info');
var gender = document.querySelectorAll('.gender');
var hobbies = document.querySelectorAll('.hobbies');
//分割得到id
var getUpdateId = location.search.split('=')[1];
getData(baseUrl + '/api/student/getStudent', { id: getUpdateId }, function(xhr) {
    // 得到对象
    var updateObj = JSON.parse(xhr.responseText)[0];
    for (var i = 0; i < updateInfo.length; i++) {
        //input框的值等于对象的值，对象的通过属性得到，属性就是input框的name
        updateInfo[i].value = updateObj[updateInfo[i].name];
    };
    for (var j = 0; j < gender.length; j++) {
        if (updateObj.gender == gender[j].value) {
            gender[j].checked = true;
        };
    };
    for (var k = 0; k < hobbies.length; k++) {
        console.log(updateObj.hobby);
        if (updateObj.hobby.includes(hobbies[k].value)) {
            hobbies[k].checked = true;
        };
    };
});
var allStuData = {};
updateForm.onsubmit = function(e) {
    for (var i = 0; i < updateInfo.length; i++) {
        allStuData[updateInfo[i].name] = updateInfo[i].value;
    };
    for (var j = 0; j < gender.length; j++) {
        if (gender[j].checked) {
            allStuData.gender = gender[j].value;
            break;
        };
    };
    var arrStu = [];
    for (var k = 0; k < hobbies.length; k++) {
        if (hobbies[k].checked) {
            arrStu.push(hobbies[k].value);
        };
    };
    allStuData.hobby = arrStu.join();
    allStuData.id = getUpdateId;
    postData(baseUrl + '/api/student/updateStudent', allStuData, function() {
        location.href = location.origin + '/index.html';
    });
    console.log(allStuData);
    e.preventDefault();

};