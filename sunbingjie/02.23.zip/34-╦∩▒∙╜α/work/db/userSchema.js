const mongoose = require('mongoose');
const userSchema = new mongoose.Schema({
    // name: String,
    // age: Number,
    // gender: String,
    // hobby: String
    name: {
        type: String
    },
    age: {
        type: Number
    },
    gender: {
        type: String
    },
    hobby: {
        type: String
    },
    tel: {
        type: String

    },
    address: {
        type: String
    },
    remark: {
        type: String

    },
    date: {
        type: String

    },
    id: {
        type: String
    },
    clazz: {
        type: String
    }
});
const User = mongoose.model('user', userSchema);
module.exports = User;