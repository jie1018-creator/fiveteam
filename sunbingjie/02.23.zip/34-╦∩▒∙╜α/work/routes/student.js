const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
//数据库
require('../db/db.js');
let user = require('../db/userSchema.js');
//得到所有数据,查询数据
router.get('/getStudent', (req, res) => {
    user.find(req.query).then((data) => {
        res.send(200, data)
    });
});
//删除数据
router.get('/removeStudent', (req, res) => {
    // console.log(req.query) //通过id删除数据,req.body得到的是一个对象,里面值含有要删除数据的id键值对
    user.deleteOne({ id: req.query.id }).then((rel) => {
        //通过id删除数据库中的数据
        user.find().then((data) => {
            res.send(200, data)
        });
    })
});
//添加数据
router.post('/addStudent', (req, res) => {
    //添加数据时自动生成时间戳作为数据的id
    req.body.id = Date.now().toString();
    //使用数据库的方法create添加数据到数据库中
    user.create(req.body).then((data) => {
        res.send(200, data)
    })
});
//更新数据
router.post('/updateStudent', (req, res) => {
    // console.log(req.body)//根据id找到的符合条件的整条数据
    user.updateOne({
        id: req.body.id
    }, req.body).then((rel) => {
        res.send(200, rel)
    })
});
module.exports = router;