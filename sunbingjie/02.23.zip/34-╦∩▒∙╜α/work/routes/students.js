const express = require('express');
const app = express();
const cors = require('cors');
const router = express.Router();
//连接数据库
require('../db/db.js');
let user = require('../db/userSchema.js');
//get:getStudent,removeStudent
//post:addStudent,updateStudent
//查询所有的数据
router.get('/getStudent', (req, res) => {
    user.find().then((data) => {
        res.send(200, data)
    });
});
//搜索数据,给搜索数据操作一个单独的接口,可以实现查询数据
router.get('/searchStudent', (req, res) => {
    // console.log(req.query);//得到的是只有name键值对的对象
    // { name: req.query.name }
    user.find(req.query).then((data) => {
        res.send(200, data)
    });
});
//删除数据
router.get('/removeStudent', (req, res) => {
    user.deleteOne(req.body).then((data) => {
        //重新查找所有数据,如果直接写res.send会出现查找刚删掉的数据,在页面中打印未查找到数据
        user.find().then((data) => {
            res.send(200, data)
        })
    });
});
//添加数据
router.post('/addStudent', (req, res) => {
    req.body.id = Date.now().toString(); //生成时间戳作为id
    user.create(req.body).then((rel) => {
        res.send(200, rel)
    });
});
//更新数据
router.post('/updateStudent', (req, res) => {
    //通过id记录数据修改,修改后的数据返回到表格中
    user.updateOne({ id: req.body.id }, req.body).then((rel) => {
        res.send(200, rel)
    });
});
module.exports = router;