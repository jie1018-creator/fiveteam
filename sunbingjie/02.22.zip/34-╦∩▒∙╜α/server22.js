const express = require('express');
const app = express();
const fs = require('fs');
const ejs = require('ejs');
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
// app.set('views', __dirname + '/views');
//通过get将数据写入到页面中
app.get('/', (req, res) => {
    fs.readFile('./data/students.json', 'utf-8', (err, data) => {
        if (err) {
            res.status(500).end();
            console.log(err);
        } else {
            studentsObj = JSON.parse(data);
            // ejs.renderFile('./views/index.ejs', studentsObj, (err, str) => {
            //     if (err) {
            //         res.writeHead(500, {
            //             'Content-Type': 'text/plain;charset=utf-8'
            //         });
            //         res.end();
            //     } else {
            //         res.writeHead(200, {
            //             'Content-Type': 'text/html;charset=utf-8'
            //         });
            //         res.end(str); //str就是整个ejs文件的内容
            //         // console.log(str);
            //     }
            // });
            res.render("index", studentsObj);
        };
    })
});
app.get('/login', (req, res) => {
    res.render("login", { title: '登录' });
});
app.post('/submit', (req, res) => {
    res.render("page", { uname: req.body.uname })
});
app.listen(3000, () => {
    console.log('端口3000开启');
});