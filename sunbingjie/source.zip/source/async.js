// let fs = require('fs');
// let reafile = function(filename) {
//     return new Promise((resolve, reject) => {
//         fs.readFile(filename, 'utf-8', (err, data) => {
//             if (err) {
//                 reject(err);
//             } else {
//                 resolve(data);
//             }
//         })
//     })
// };
// let refile = function(oldfile, newfile) {
//     return new Promise((resolve, reject) => {
//         fs.rename(oldfile, newfile, (err) => {
//             if (err) {
//                 reject('重命名失败');
//             } else {
//                 resolve('重命名成功');
//             };
//         });
//     })
// };
// async异步执行
// function aawait(filename) {
//     return new Promise((resolve, reject) => {
//         fs.readFile(filename, 'utf-8', (err, data) => {
//             if (err) {
//                 reject(err);
//             } else {
//                 resolve(data);
//             }
//         })
//     })
// };
// async function funAsync() {
//     let file1 = await aawait('./file/1.txt');
//     let file2 = await aawait('./file/2.txt');
//     let file3 = await aawait('./file/3.txt');
//     console.log(file1);
//     console.log(file2);
//     console.log(file3);
// };
// funAsync();