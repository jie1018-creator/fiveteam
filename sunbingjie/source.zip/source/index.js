// console.log(123);
// let fs = require('fs');

// console.log(fs);
//读取文件
// fs.readFile('./file/1.txt', 'utf-8', (err, data) => {
//     if (err) {
//         console.log(err, '读取错误');
//     } else {
//         console.log('读取成功', data);
//     }
// });
//写入文件
// fs.writeFile('./file/2.txt', '早上好123', (err) => {
//     if (err) {
//         console.log('写入错误');
//     } else {
//         console.log('写入成功');
//     };
// });
//追加内容
// fs.appendFile('./file/1.txt', '追加的东西', (err) => {
//     if (err) {
//         console.log('追加失败');
//     } else {
//         console.log('追加成功');
//     };
// });
//删除文件
// fs.unlink('./file/del.txt', (err) => {
//     if (err) {
//         console.log('删除失败');
//     } else {
//         console.log('删除成功');
//     };
// });
//重命名文件
// fs.rename('./file/rename.txt', './file/2.txt', (err) => {
//     if (err) {
//         console.log('重命名失败');
//     } else {
//         console.log('重命名成功');
//     };
// });
//异步的非阻塞的操作

//同步操作
// let data = fs.readFileSync('./file/1.txt', 'utf-8');
// console.log(data); //返回值是读取的内容
//捕获异常
// try {
//     let data = fs.readFileSync('./file/1.txt', 'utf-8');
//     console.log(data);
// } catch (error) {
//     console.log(error);
// };



//异步操作
// 使用promise
// 重命名文件
// fs.rename('./file/rename.txt', './file/2.txt', (err) => {
//     if (err) {
//         console.log('重命名失败');
//     } else {
//         console.log('重命名成功');
//     };
// });
// fs.readFile('./file/1.txt', 'utf-8', (err, data) => {
//     if (err) {
//         console.log(err, '读取错误');
//     } else {
//         console.log('读取成功', data);
//     }
// });
// let reafile = function(filename) {
//     return new Promise((resolve, reject) => {
//         fs.readFile(filename, 'utf-8', (err, data) => {
//             if (err) {
//                 reject(err, '读取错误');
//             } else {
//                 resolve('读取成功', data);
//             }
//         })
//     })
// }
// let refile = function(oldfile, newfile) {
//     return new Promise((resolve, reject) => {
//         fs.rename(oldfile, newfile, (err) => {
//             if (err) {
//                 reject('重命名失败');
//             } else {
//                 resolve('重命名成功');
//             };
//         });
//     })
// };
// 使用then方法
// reafile('./file/1.txt').then(function(data) {
//     console.log(data);
//     return reafile('./file/2.txt')
// }).then(function(data) {
//     console.log(data);
//     return refile('./file/rename.txt', './file/3.txt')
// }).then(function(data) {
//     console.log(data);
// })