// let fs = require('fs');
//创建一个文件夹
// fs.mkdir('./file/test', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('创建成功');
//     }
// });

//判断是一个文件还是一个,目录
// fs.stat('./file/1.txt', (err, stats) => {
//     if (err) {
//         console.log(err);
//     } else {
//是否是一个目录
//         if (stats.isDirectory()) {
//             console.log('是一个目录');
//         } else if (stats.isFile()) {
//是否是一个文件
//             console.log('是一个文件');
//         };
//     };
// });

//删除空的文件夹
// fs.rmdir('./file/test', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('删除成功');
//     }
// });

//读取文件夹,读取到文件夹下面的文件名,数组形式
// fs.readdir('./file/test', (err, files) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log(files);
//     }
// });