let http = require('http');
let server = http.createServer((req, res) => {
    var requ = req.url;
    console.log(requ);
    res.writeHead(200, 'success', {
        'Content-Type': 'text/html;charset=utf-8'
    });
    switch (requ) {
        case '/':
            res.write('home page');
            break;
        case '/index.html':
            res.write('home page');
            break;
        case '/news.html':
            res.write('news page');
            break;
        case '/page.html':
            res.write('page');
            break;
        default:
            res.write('404 Not Found')
    };
    res.end('running');
});
server.listen(3000, () => {
    console.log('server is running');
});