let fs = require('fs');
let http = require('http');

let server = http.createServer((req, res) => {
    res.writeHead(200, 'success', {
        'Content-Type': 'text/html;charset=utf-8'
    });
    if (req.url != '/favicon.ico') {
        let requ = './files' + req.url;
        fs.readFile(requ, (err, data) => {
            if (err) {
                console.log(err);
            } else {
                res.write(data)
            };
            res.end('endend');
        })
    }
});
server.listen(3000, () => {
    console.log('server is running');
});