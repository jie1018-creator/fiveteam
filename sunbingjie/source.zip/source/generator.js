// function* fun() {
//     console.log(1);
//     yield '11';
//     console.log(2);
//     yield '22';
//     console.log(3);
//     yield '33';
// };
// var rel = fun();
// console.log(rel.next());
// console.log(rel.next());
// console.log(rel.next());
// console.log(rel.next());
// let fs = require('fs');
// let reafile = function(filename) {
//     return new Promise((resolve, reject) => {
//         fs.readFile(filename, 'utf-8', (err, data) => {
//             if (err) {
//                 reject(err);
//             } else {
//                 resolve(data);
//             }
//         })
//     })
// }
// let refile = function(oldfile, newfile) {
//     return new Promise((resolve, reject) => {
//         fs.rename(oldfile, newfile, (err) => {
//             if (err) {
//                 reject('重命名失败');
//             } else {
//                 resolve('重命名成功');
//             };
//         });
//     })
// };

// function* gen() {
//     yield reafile('./file/1.txt');
//     yield reafile('./file/2.txt');
//     yield refile('./file/3.txt', './file/4.txt');
// };
// var genrel = gen();
// genrel.next().value.then(data => {
//     console.log(data);
//     return genrel.next().value
// }).then(data => {
//     console.log(data);
//     return genrel.next().value
// }).then(data => {
//     console.log(data);
// })