// generator生成器
//和普通函数的区别
//function后边右边一个*标志,和yield一起使用
//function* fun() {
//     console.log(1);
//     yield '11';
//     console.log(2);
//     yield '22';
//     console.log(3);
//     yield '33';
// };
// var rel = fun();
// console.log(rel.next().value);
// console.log(rel.next().value);
// console.log(rel.next().value);

let fs = require('fs');
//读取文件
let refile = function(filename) {
    return new Promise((resolve, reject) => {
        fs.readFile(filename, 'utf-8', (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        })
    })
};
//文件重命名
let rename = function(oldname, newname) {
    return new Promise((resolve, reject) => {
        fs.rename(oldname, newname, err => {
            if (err) {
                reject(err)
            } else {
                resolve('重命名成功')
            }
        })
    })
};

function* gen() {
    yield refile('./file/1.txt');
    yield refile('./file/2.txt');
    yield rename('./file/33.txt', './file/3.txt');
};
var genrel = gen();
genrel.next().value.then(data => {
    console.log(data);
    return genrel.next().value
}).then(data => {
    console.log(data);
    return genrel.next().value
}).then(data => {
    console.log(data);
})