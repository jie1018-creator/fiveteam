//解决异步操作
//es6中
// var rel = new Promise(function(resolve, reject) {
//     setTimeout(function() {
//         var num = Math.floor(Math.random() * 10)
//         if (num > 5) {
//             reslove('执行成功');
//         } else {
//             reject('执行失败');
//         }
//     }, 1000)
// });
// rel.then(function(data) {
//     console.log(data);
// }, function(err) {
//     console.log(err);
// });

// const { resolve } = require("path")

let fs = require('fs');
// 使用promise来处理异步程序
let refile = function(filename) {
    return new Promise((resolve, reject) => {
        fs.readFile(filename, 'utf-8', (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        })
    })
};
let renfile = function(oldname, newname) {
    return new Promise((resolve, reject) => {
        fs.rename(oldname, newname, err => {
            if (err) {
                reject(err);
            } else {
                resolve('重命名成功')
            }
        })
    })
};
refile('./file/1.txt').then(function(data) {
    console.log(data);
    return refile('./file/2.txt');
}).then(function(data) {
    console.log(data);
    return renfile('./file/3.txt', './file/33.txt')
}).then(function(data) {
    console.log(data);
});