let fs = require('fs');
// 在es6中
function fun(filename) {
    return new Promise((resolve, reject) => {
        fs.readFile(filename, 'utf-8', (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        })
    })
};
async function funasync() {
    let file1 = await fun('./file/1.txt')
    let file2 = await fun('./file/2.txt')
    let file3 = await fun('./file/3.txt')
    console.log(file1);
    console.log(file2);
    console.log(file3);
};
funasync()