//读取文件,删除文件,写入文件,追加文件,重命名文件,异步的非阻塞操作
let fs = require('fs');
//读取文件操作
// fs.readFile('./file/1.txt', 'utf-8', (err, data) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log(data);
//     }
// });

//写入文件操作,就是在问价里面添加内容,会把原先文件里面的内容替换掉
// fs.writeFile('./file/1.txt', '写入的内容', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('写入成功');
//     };
// });

//追加文件,就是在原先的文件夹下或者文件下面添加一个新的文件
// fs.appendFile('./file/2.txt', '追加的文件', err => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('追加成功');
//     };
// });


//删除文件
// fs.appendFile('./file/del.txt', '要被删除的文件', err => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('追加成功');
//     }
// });
// fs.unlink('./file/del.txt', err => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('删除成功');
//     }
// });

//重命名文件
//准备一个被重命名的文件
// fs.appendFile('./file/rename.txt', '被重命名的文件', err => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('追加成功');
//     };
// });
//重命名操作
// fs.rename('./file/rename.txt', './file/3.txt', err => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('重命名成功');
//     }
// });


//同步操作一般不用后边加上Sync