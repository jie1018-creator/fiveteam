// 创建文件夹,删除文件夹,读取文件夹
let fs = require('fs');
// fs.mkdir('./file/test', err => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('创建成功');
//     }
// });


// fs.rmdir('./file/test', err => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('删除成功');
//     }
// });

// fs.mkdir('./file/test', err => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('创建成功');
//     }
// });
// fs.appendFile('./file/test/11.txt', '111111', err => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('添加成功');
//     }
// });
// fs.appendFile('./file/test/22.txt', '22222', err => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('添加成功');
//     }
// });

fs.readdir('./file', (err, files) => {
    if (err) {
        console.log(err);
    } else {
        console.log(files);
    }
});
fs.readdir('./file', { withFileTypes: true }, (err, files) => {
    if (err) {
        console.log(err);
    } else {
        console.log(files);
    }
});