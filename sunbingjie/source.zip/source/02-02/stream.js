// 创建一个写入流
let fs = require('fs');
// let cws = fs.createWriteStream('./file/1.txt');
// cws.write('123新写入的内容');
// cws.end();
// cws.on('finish', () => {
//     console.log('写入完成');
// });
//读取流
// let crs = fs.createReadStream('./file/1.txt');
// let str = '';
// crs.on('data', (datastr) => {
//     str += datastr;
// });
// crs.on('end', () => {
//     console.log(str);
// });
//pipe
let cws = fs.createWriteStream('./file/1.txt');
let crs = fs.createReadStream('./file/2.txt');
crs.pipe(cws);
crs.on('end', () => {
    console.log('读取完成');
})