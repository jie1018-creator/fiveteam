//引入fs文件系统模块
const fs = require('fs');
//封装函数
function delDir(p) {
    //读取文件夹中所有文件和文件夹 数组的形式保存
    var files = fs.readdirSync(p);
    console.log(files); //[ '01-sd.html', '1.txt', '2.txt', '3.txt', 'css', 'js' ]
    //通过for in 遍历文件中的文件和目录

    files.forEach((value, index) => {
        var url = p + '/' + files[index];
        // console.log(value);
        // console.log(files[index]);
        // console.log(index);
        // console.log(url);
        //读取文件信息
        var stats = fs.statSync(url);
        if (stats.isFile()) {
            //当前为文件,删除文件
            console.log('是一个文件');
            fs.unlinkSync(url);

        } else if (stats.isDirectory()) {
            console.log('是一个目录');
            //当前为一个目录 进行递归 调用自身
            delDir(url);
        };

    });
    //遍历结束 删除所有文件夹内的文件 和文件夹 成为一个空文件夹
    fs.rmdirSync(p);
    console.log('删除此非空文件夹成功');
}
//调用
delDir('../dddd');