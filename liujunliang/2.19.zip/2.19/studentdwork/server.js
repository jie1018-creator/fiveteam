//引入express框架
const express = require('express');
//引入第三方包
const bodyParser = require('body-parser');


//引入文件操作系统
const fs = require('fs');

//初始化express框架
let app = express();

//设置POST请求读取格式
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


//跨域请求
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Content-Type', 'application/json');
    next();
});

//设置接口以及处理函数
//get获取数据 查找数据
app.get("/api/student/getstudent", (req, res) => {
    fs.readFile("./data/student.json", 'utf-8', (err, data) => {
        if (err) {
            console.log('文件读取错误' + err);
            res.status(500).send('服务器错误');
        } else {
            studentData = JSON.parse(data);

            //存放查找结果
            let apple = [];
            if (req.query.id) {
                studentData.forEach((value, index) => {
                    if (value.id == req.query.id) {
                        //符合的加入结果
                        apple.push(value);
                    }
                });
            } else if (req.query.name) {
                studentData.forEach((value, index) => {
                    if (value.name == req.query.name) {
                        //符合的加入结果
                        apple.push(value);
                    }
                });
            } else {
                //当没有结果时,返回全部数据
                apple = studentData;
            }
            res.status(200).send(apple);

        };
    });
});

//post 添加数据
app.post("/api/student/addstudent", (req, res) => {
    //读取文件获取数据
    fs.readFile('./data/student.json', 'utf-8', (err, data) => {
        if (err) {
            console.log('读取文件出错' + err);
            res.status(500).send('服务器出错!');
        } else {
            studentData = JSON.parse(data);
            let apple = req.body;
            studentData.push(apple);
            fs.writeFileSync('./data/student.json', JSON.stringify(studentData, null, 4));
            res.status(200).send(apple);
        };
    });
});
//监听
app.listen(3000, () => {
    console.log('3000端口打开');
})