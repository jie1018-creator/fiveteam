const express = require('express');
const app = express();
// 获取请求的url相关内容
// http://localhost:3000/login?uname=zhangmeili&password=666
// app.get('/find/:id', (req, res) => {
//     console.log(req.params);
//     console.log(req.params.id);
//     res.status(200).send('05');

// });
// app.get('/login:id/apple/:IDX', (req, res) => {
//     console.log(req.params);
//     res.status(200).send('05');

// });

// app.get('/login:id/uname/:uname1/passward/:passward1', (req, res) => {
//     console.log(req.params);
//     res.status(200).send('05');

// });
app.get('/login:id/uname/:uname1/passward/:passward1', (req, res) => {
    console.log(req.params);
    res.status(200).send(req.params);

});
app.listen(3000, () => {
    console.log('3000开启');
});