const express = require('express');
const app = express();
app.get('/getstudent', (req, res) => {
    console.log(req.url);
    res.send('02-get getstudent');

});
app.get('/getschool', (req, res) => {
    console.log(req.url);
    res.send('02-get getschool');

});
//程序监听3000端口
app.listen(3000);