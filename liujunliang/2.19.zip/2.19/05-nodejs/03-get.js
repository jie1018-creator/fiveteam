const express = require('express');
const app = express();
app.get('/request', (req, res, next) => {
    console.log(req.url);
    req.name = '法外狂徒';
    next();

});
app.get('/request', (req, res) => {
    res.send(req.name);
    res.status(202).send(req.name);

});
//程序监听3000端口
app.listen(3000);