const express = require('express');
const app = express();
// 获取请求的url相关内容
// http://localhost:3000/login?uname=zhangmeili&password=666
app.use((req, res, next) => {
    console.log(req.url);
    next();
});
app.use('/login', (req, res) => {
    console.log(req.query);
    res.status(200).send(req.query);
});
app.listen(3000, () => {
    console.log('3000开启');
});