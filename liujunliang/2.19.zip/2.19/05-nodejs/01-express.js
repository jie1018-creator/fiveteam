const express = require('express');
//生成一个express实例app
var app = express();
app.get('/', (req, res) => {
    // 对客户端做出响应 send方法会根据内容的类型自动设置请求头
    res.send('Hello Express');
});
//程序监听3000端口
app.listen(3000);