//引入模块
const ejs = require('ejs');
var data = {
    apple: "<script>document.write(6666)</script>",
    apple1: '123你好asd!@#<()>?'
};
var template =
    `<p>Hello <%=apple%> </p>
    <p>Hello <%-apple%> </p>    
    <p>Hello <%=apple1%> </p>
    <p>Hello <%-apple1%> </p>
`;
//<%=输出转义的数据到模板
//运行脚本 的代码 要考虑安全问题
//<%- 输出非转义的数据到模板
var work = ejs.render(template, data);
console.log(work);