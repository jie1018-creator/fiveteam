const ejs = require('ejs');
let dataObj = ['apple', 'food', 'org'];
//<% '脚本' 标签，用于流程控制，无输出
let template = `
<%   laObj.forEach(function(value){   %>

    <h2>  <%= value %> </h2>
    
    <% });  %>
`;
let htmls = ejs.render(template, {
    laObj: dataObj
});
console.log(htmls);