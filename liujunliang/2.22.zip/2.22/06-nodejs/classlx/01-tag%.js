//引入模块
const ejs = require('ejs');

//数据
var data = {
    name: '张三'
};

var template = `<p> Hello <%=name%> </P>`
var work = ejs.render(template, data);
console.log(work);