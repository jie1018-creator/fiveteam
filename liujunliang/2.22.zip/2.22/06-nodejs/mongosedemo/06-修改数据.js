const mongoose = require('mongoose');
let DB = mongoose.connect('mongodb://localhost/momokodb', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('ok');
}, () => {
    console.log('none');
});

const userSchema = new mongoose.Schema({
    name: String,
    age: Number,
    gender: String
});

const User = mongoose.model('user', userSchema);

// User.updateOne({ uname: "就这" }, { uname: "宋七" }).then((rel) => {
//     console.log(rel);
// });

// User.updateOne({ age: 58 }, { age: 68 }).then((rel) => {
//     console.log(rel);
// });
// User.updateMany({}, { gender: "女" }).then((rel) => {
//     console.log(rel);
// });

User.updateMany({ age: 58 }, { gender: "女神" }).then((rel) => {
    console.log(rel);
});