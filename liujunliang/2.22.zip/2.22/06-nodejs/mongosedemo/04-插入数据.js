const mongoose = require('mongoose');
let DB = mongoose.connect('mongodb://localhost/momokodb', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('ok');
}, () => {
    console.log('none');
});

const userSchema = new mongoose.Schema({
    clazz: String,
    name: String,
    age: Number,
    tel: Number,
    remark: String,
    date: String,
    gender: String,
    hobby: String,
    address: String,
    id: Number,
});

const User = mongoose.model('user', userSchema);
//插入一条

// User.create({
//     name: '高明',
//     age: 78,
//     gender: '男'
// }).then((result) => {
//     console.log(result);
// // });
// 插入多条
User.create({
    clazz: "火花25",
    name: "赵芬",
    age: "18",
    tel: "18537289345",
    remark: "程序员小公主",
    date: "2020-12-01",
    gender: "女",
    hobby: "睡觉",
    address: "郑州",
    id: 1583058959373
}, {
    clazz: "火花25",
    name: "李智",
    age: "18",
    tel: "18537289346",
    remark: "医生",
    date: "2020-12-01",
    gender: "男",
    hobby: "睡觉,学习",
    address: "郑州",
    id: 1583058959383
}, {
    clazz: "火花25",
    name: "闫钊",
    age: "18",
    tel: "18537289347",
    remark: "教授",
    date: "2020-12-01",
    gender: "男",
    hobby: "学习",
    address: "漯河",
    id: 1583058959391
}, {
    clazz: "火花25",
    name: "尹明远",
    age: "22",
    tel: "110",
    remark: "单身程序员",
    date: "2020-12-02",
    gender: "男",
    hobby: "吃饭",
    address: "郑州",
    id: 1583060041757
}, {
    clazz: "火花25",
    name: "安鹏展",
    age: "22",
    tel: "120",
    remark: "程序员",
    date: "2020-12-01",
    gender: "男",
    hobby: "吃饭",
    address: "郑州",
    id: 1583132336008
}, {
    clazz: "火花25",
    name: "孙冰洁1",
    age: "18",
    tel: "123",
    remark: "程序员女神",
    date: "2020-12-01",
    gender: "女",
    hobby: "吃饭",
    address: "郑州",
    id: 1583134609106
}, {
    clazz: "火花25",
    name: "杨雪静",
    age: "18",
    tel: "18537289345",
    remark: "程序员小公主",
    gender: "女",
    hobby: "睡觉",
    address: "郑州",
    id: 1607389119655,
    date: "2020-12-8"
}).then((result) => {
    console.log(result);
});