// 第一步
// 安装
// npm install express --save
// npm install ejs --save
// 引入fs
const express = require('express');

// 不引入也可以
const fs = require('fs');
const ejs = require('ejs');

//实例化
let app = express();

//引入
const bodyParser = require('body-parser');
//拦截请求
app.use(bodyParser.urlencoded({ extended: false }));

//设置expre设置模板引擎
app.set('view engine', 'ejs');
//找到views里面的ejs文件默认也可以不写
//app.set('views',__dirname+'views');



//请求数据
app.get("/", (req, res) => {
    fs.readFile('./data/student.json', 'utf-8', (err, data) => {
        if (err) {
            console.log('读取文件出错' + err);
            res.status(500).send('服务器出错');
        } else {
            data = JSON.parse(data);

            // ejs.renderFile("./views/index.ejs", studentsObj, (err, str) => {
            //     if (err) {
            //         res.writeHead(500, {
            //             'Content-Type': 'text/plain;charset="utf-8"'
            //         });
            //         res.end('500 - application ERROR');

            //     } else {
            //         res.writeHead(200, {
            //             'Content-Type': 'text/html;charset="utf-8"'
            //         });
            //         res.end(str);
            //         // res.end('11');

            //     };
            // });


            // 要的是传递对象的键值 (页面的html资源所在的ejs文件的前缀,对象数据键值对) 
            res.render("index", { studentsObj: data });

        };
    });
});


app.get('/login', (req, res) => {
    //要的是传递对象的键值   title 键 --引        '登录'值  --用
    res.render('login', { title: '登录' });
});

// 登录后到登录后的首页面

app.post('/submit', (req, res) => {
    console.log(req.body);
    res.render('mainPage', {
        title: '登录后的页面',
        uname: req.body.uname
    });
});

app.listen(3000, () => {
    console.log('3000端口开启');
});