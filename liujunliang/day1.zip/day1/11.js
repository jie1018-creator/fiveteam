let fs = require('fs');
// 创建文件夹创建文件夹,递归创建
// recursive: true:递归的创建

// 创建 `/目录1/目录2/目录3`，
// 不管 `/目录1` 和 `/目录1/目录2` 是否存在。



// fs.mkdir('./css/index.css', {
//     recursive: true
// }, (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('目录创建成功');
//     }
// });

// 删除一个不是空的文件夹
// fs.rmdir('./css', {
//     recursive: true
// }, (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('目录删除成功');
//     }
// });

// 读取文件夹文件的类型
fs.readdir('./files', {
    withFileTypes: true
}, (err, files) => {
    if (err) {
        console.log(err);
    } else {
        console.log(files);
    }
});