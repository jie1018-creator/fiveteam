let fs = require('fs');
let dataInfo = '螃蟹在剥我的壳，笔记本在写我。漫天的我落在枫叶上雪花上。而你在想我\n';
// 创建一个写入流
// cWS: <fs.WriteStream>
let cWs = fs.createWriteStream('./files/cw.txt');
//写入
// cWs.write(dataInfo);
// cWs.write(dataInfo);

for (let i = 0; i < 100; i++) {
    cWs.write(dataInfo);
};
//写入完成
cWs.end();
//完成
cWs.on('finish', () => {
    console.log('写入文件完成');
});