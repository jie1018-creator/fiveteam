let fs = require('fs');
const { data } = require('jquery');
// 读取文件
let read = function(filename) {
    return new Promise((resolve, reject) => {
        fs.readFile(filename, 'utf-8', (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    });
};
// 重命名文件
let rename = function(oldName, newName) {
    return new Promise((resolve, reject) => {
        fs.rename(oldName, newName, (err) => {
            if (err) {
                reject(err);
            } else {
                resolve('重命名成功');
            }
        });
    });
};

// 创建一个generator函数
function* readre() {
    yield read('./files/1.txt');
    yield read('./files/2.txt');
    yield rename('./files/rename.txt', './files/name.txt');
};
//调用
var relre = readre();
// console.log(relre.next().value);
relre.next().value.then(data => {
    console.log(data);
    return relre.next().value;
}).then(data => {
    console.log(data);
    return relre.next().value;
}).then(data => {
    console.log(data);
});