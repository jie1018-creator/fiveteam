// fs（文件系统）
// 读取文件
// 写入文件
// 追加内容
// 删除文件
// 重命名文件......

let fs = require('fs');
// console.log(fs);
//读取文件:fs.readFile()
// fs.readFile('./files/1.txt', (err, data) => {
//     if (err) {
//         console.log(err);
//     } else {
//         // Buffer:是一种数据暂时暂时存储区,用来临时存储一些数据(二进制数据)
//         console.log(data);
//         // toString() 方法可以根据所传递的参数把数值转换为对应进制的数字字符串
//         console.log(data.toString());
//     }
// });

// fs.readFile('./files/1.txt', 'utf-8', (err, data) => {
//     if (err) {
//         console.log(err);
//     } else {
//         // Buffer:是一种数据暂时暂时存储区,用来临时存储一些数据(二进制数据)
//         console.log(data);
//     }
// });

//写入文件 //没有文件时,会新建一个  覆盖
// fs.writeFile('./files/2.txt', '写入文件', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('写入成功');
//     }
// });



//追加数据
fs.appendFile('./files/2.txt', '   追加数据文件', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('追加成功');
    }
});


// 异步操作:非阻塞操作

//删除文件
// fs.unlink('./files/del.txt', (err) => {
//     if (err) {
//         console.log(err);
//     } else {
//         console.log('删除成功');
//     }
// });

//重命名文件
fs.rename('./files/rename.txt', './files/name.txt', (err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('重命名成功');
    }
});