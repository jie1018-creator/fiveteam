// 引入文件系统模块
let fs = require('fs');
// 同步读取****  只有返回值 不能捕获异常
// 返回值是读取的内容
// let data = fs.readFileSync('./files/2.txt', 'utf8'); //存在 

// let data = fs.readFileSync('./files/3.txt', 'utf8'); //不存在 
// console.log(data);
// 捕获异常
try {
    let data = fs.readFileSync('./files/3.txt', 'utf8');
    console.log(data);

} catch (error) {
    // 异常读取
    console.log(error);
}