let fs = require('fs');
// 创建读取流
let cRS = fs.createReadStream('./files/1.txt');
// 创建写入流
let cWS = fs.createWriteStream('./files/2.txt');
// 读取流的方法pipe()  管道

// 将1.txt 读取  写入 2.txt
cRS.pipe(cWS);
// 读取完成
cRS.on('end', () => {
    console.log('读取完成');

});