// 读ejs
module.exports = (req, res) => {
    res.render('./admin/productlist');
}