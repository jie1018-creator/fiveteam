const mongoose = require('mongoose');
let DB = mongoose.connect('mongodb://localhost/momokodb', { useNewUrlParser: true, useUnifiedTopology: true });
DB.then(() => {
    console.log('ok');
}, () => {
    console.log('none');
});

const userSchema = new mongoose.Schema({
    name: String,
    age: Number,
    gender: String
});

const User = mongoose.model('user', userSchema);

// User.deleteOne({ age: 58 }).then((rel) => {
//     console.log(rel);
// });
// {n: 1, ok: 1, deletedCount: 1 }

User.deleteMany({ age: 58 }).then((rel) => {
    console.log(rel);
});