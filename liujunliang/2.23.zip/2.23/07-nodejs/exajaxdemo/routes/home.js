const express = require('express');
const router = express.Router();
router.get('/', (req, res) => {
    res.send('主页面的home');
});

//暴露router
module.exports = router;