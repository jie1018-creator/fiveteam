const express = require('express');
// express 中有Rouster方法
const router = express.Router();
//通过router 配置二级路由
router.get('/login', (req, res) => {
    res.send(200, 'login成功');
});

//暴露router
module.exports = router;