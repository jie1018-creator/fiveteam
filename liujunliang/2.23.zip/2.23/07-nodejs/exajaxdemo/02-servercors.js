const express = require('express');
const app = express();
const cors = require('cors');
// cors：cross-Origin-resouce-sharing:跨域资源共享

//解决跨域问题的中间件
app.use(cors());

//引入数据库的代码
require('./db/db.js');
let userschma = require('./db/userschma');


//接口 /api/student/getStudent
//get请求
app.get('/api/student/getStudent', (req, res) => {
    userschma.find().then((data) => {
        res.status(200).send(data);
    });
});
app.listen(3008, () => {
    console.log('3008端口打开');
})