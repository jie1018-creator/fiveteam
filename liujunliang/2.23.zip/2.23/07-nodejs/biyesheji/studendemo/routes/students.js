const express = require('express');
// express 中有Rouster方法
const router = express.Router();
//通过router 配置二级路由

//引入数据库的代码
require('../db/db.js');
let userschma = require('../db/userschma.js');

//获取所有数据以及查询部分数据 
router.get('/getStudent', (req, res) => {
    //判断姓名匹配
    // console.log(req.query);
    if (req.query.name) {

        //精准查询
        userschma.find({ name: req.query.name }).then((data) => {
            res.status(200).send(data);
        }, () => {
            res.status(500).send('请求失败')
        });
        //更新时判断id获取数据 进行修改
    } else if (req.query.id) {
        //精准查询
        userschma.find({ id: req.query.id }).then((data) => {
            res.status(200).send(data);
        }, () => {
            res.status(500).send('请求失败')
        });
    } else {
        userschma.find().then((data) => {
            res.status(200).send(data);
        }, () => {
            res.status(500).send('请求失败')
        });
    }


});

//删除学生信息
router.get('/removeStudent', (req, res) => {
    //判断id
    // console.log(req.query);
    if (req.query.id) {

        //精准删除该数据
        userschma.deleteOne({ id: req.query.id }).then((data) => {
            res.status(200).send('删除成功');
        }, () => {
            res.status(500).send('删除请求失败')
        });
    } else {
        // 没有id返回500提醒
        res.status(500).send('id不能为空');
    }


});

//添加学生信息
router.post('/addStudent', (req, res) => {
    // 设置学生id（时间戳）
    let id = new Date().getTime();
    // 把id赋给添加的数据
    req.body.id = id;
    userschma.create(req.body).then(() => {
        res.status(200).send(req.body);
    }, () => {
        res.status(500).send('添加请求失败')
    });

});

//更新学生信息
router.post('/updateStudent', (req, res) => {
    console.log(req.body);
    userschma.updateOne({ id: req.body.id }, req.body).then(() => {
        res.status(200).send(req.body);
    }, () => {
        res.status(500).send('更新请求失败')
    });

});

//暴露router
module.exports = router;