const mongoose = require('mongoose');
const userschema = new mongoose.Schema({
    name: String,
    age: Number,
    tel: Number,
    id: Number,
    clazz: String,
    hobby: String,
    address: String,
    remark: String,
    gender: String,
    date: String
});
const User = mongoose.model('user', userschema);
module.exports = User;