//引入express
const express = require('express');
//跨域模块
const cors = require('cors');
//实例化
const app = express();
//POST请球体数据获得 引入 bodyparser
const bodyParser = require('body-parser');
//跨域
app.use(cors());
//设置post
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


//路由分发

app.use('/api/student', require('./routes/students.js'));


app.listen(3008, () => {
    console.log('3008端口开启');
});